package fi.bfk.kysely.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import fi.bfk.kysely.dao.KysymysDAO;
import fi.bfk.kysely.bean.Kysymys;


@RequestMapping(value="/")
public class KysymysController {
	
	@Inject
	public KysymysDAO dao;
	
	public KysymysDAO getDao(){
		return dao;
	}
	public void setDao(KysymysDAO dao){
		this.dao = dao;
	}

	@PreAuthorize("permitAll")
	@RequestMapping (value="/lista", method=RequestMethod.GET)
	public String getDetails(Model model){
		List<Kysymys> kysymys = dao.haeKaikki();
		model.addAttribute("kysymys",kysymys);
		return "lista";
	}
}
