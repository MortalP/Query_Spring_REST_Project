package fi.bfk.kysely.dao;

import java.util.List;

import javax.inject.Inject;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import fi.bfk.kysely.bean.Kysymys;
import fi.bfk.kysely.dao.KysymysRowMapper;
public class KysymysDAO {
	
	@Inject
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Kysymys> haeKaikki() {
		
		String sql = "select id, kysymys from Kysymys";
		RowMapper<Kysymys> mapper = new KysymysRowMapper();
		List<Kysymys> kysymys = jdbcTemplate.query(sql,mapper);
		
		return kysymys;
	}
}
