INSERT INTO Kysymys (kysymys)
VALUES 
    ("Miss� on jatkot?"),
    ("Miten menee?"),
    ("Maistuisiko olut?");
    
INSERT INTO Vastaus (vastaus, kysymys_id)
VALUES 
    ("Hyvin menee", 2),
    ("Kyll�, kunhan ei ole Koff", 3);
    
INSERT INTO Admin (kayttajatunnus, salasana)
VALUES 
    ("devaaja", "salainen");